function esc(str) {
  const d = document.createElement("div");
  d.textContent = str || "";
  return d.innerHTML;
}
function safeHref(url) {
  if (!url) return "#";
  return /^https?:\/\//i.test(url) ? url : "https://" + url;
}

document.addEventListener("DOMContentLoaded", () => {
  const params = new URLSearchParams(window.location.search);
  const slug = params.get("u");
  const previewEmail = params.get("previewEmail");
  const page = document.getElementById("pfPage");
  const wrap = document.getElementById("pfWrap");

  let data = null;
  let isPreview = false;
  if (slug) {
    data = DB.getPublished(slug);
  } else if (previewEmail) {
    data = DB.getDraft(previewEmail);
    isPreview = true;
  }

  if (!data || !data.personal || !data.personal.name) {
    wrap.innerHTML = `
      <div class="pf-empty">
        <p class="field-tag">404</p>
        <h2 class="mt-16">Nothing published here yet</h2>
        <p class="mt-16">This link doesn't match a published portfolio in this browser.</p>
      </div>`;
    document.title = "Portfolio not found";
    return;
  }

  page.classList.add(`tpl-${data.template || "modern"}`);
  document.title = `${data.personal.name} — Portfolio`;

  const links = (data.personal.links || []).filter((l) => l.url);
  const linksHtml = links.length
    ? `<div class="pf-links">${links.map((l) => `<a href="${esc(safeHref(l.url))}" target="_blank" rel="noopener">${esc(l.label || "Link")}</a>`).join("")}</div>`
    : "";

  const contactBits = [data.personal.location, data.personal.email, data.personal.phone].filter(Boolean).join("  ·  ");

  let html = `
    ${isPreview ? `<div class="field-tag" style="margin-bottom:18px;">PREVIEW — this draft isn't published yet</div>` : ""}
    <div class="pf-header">
      <p class="field-tag">${esc(contactBits || "PORTFOLIO")}</p>
      <h1>${esc(data.personal.name)}</h1>
      ${data.personal.title ? `<p class="role">${esc(data.personal.title)}</p>` : ""}
      ${data.personal.bio ? `<p class="bio">${esc(data.personal.bio)}</p>` : ""}
      ${linksHtml}
    </div>
  `;

  if (data.experience && data.experience.length) {
    html += section("Experience", data.experience.map((e) => item(
      [e.role, e.company].filter(Boolean).join(" · "),
      dateRange(e.start, e.end),
      e.description
    )));
  }
  if (data.projects && data.projects.length) {
    html += section("Projects", data.projects.map((p) => item(
      p.link ? `<a href="${esc(safeHref(p.link))}" target="_blank" rel="noopener">${esc(p.title)}</a>` : esc(p.title),
      p.tech || "",
      p.description
    )));
  }
  if (data.education && data.education.length) {
    html += section("Education", data.education.map((e) => {
      const sub = [e.degree, e.field].filter(Boolean).join(" · ");
      const desc = [sub, e.description].filter(Boolean).join(" — ");
      return item(esc(e.school), dateRange(e.start, e.end), desc);
    }));
  }
  if (data.skills && data.skills.length) {
    html += `
      <div class="pf-section">
        <p class="field-tag">Skills</p>
        <div class="pf-skill-tags">${data.skills.map((s) => `<span>${esc(s)}</span>`).join("")}</div>
      </div>`;
  }
  if (data.achievements && data.achievements.length) {
    html += section("Achievements", data.achievements.map((a) => item(a.title, a.date || "", a.description)));
  }

  html += `<div class="pf-footer">Built with Portfolio, Unfolded</div>`;
  wrap.innerHTML = html;

  function section(title, itemsHtml) {
    return `<div class="pf-section"><p class="field-tag">${esc(title)}</p><h2>${esc(title)}</h2>${itemsHtml.join("")}</div>`;
  }
  function item(titleHtml, when, description) {
    return `
      <div class="pf-item">
        <div class="pf-item-top">
          <h3>${titleHtml}</h3>
          ${when ? `<span class="when">${esc(when)}</span>` : ""}
        </div>
        ${description ? `<p>${esc(description)}</p>` : ""}
      </div>`;
  }
  function dateRange(start, end) {
    return [start, end].filter(Boolean).join(" – ");
  }
});
