document.addEventListener("DOMContentLoaded", () => {
  const user = DB.requireAuth();
  if (!user) return;

  let draft = DB.getDraft(user.email);
  const saveNote = document.getElementById("saveNote");
  let saveTimer = null;

  function scheduleSave() {
    saveNote.textContent = "Saving…";
    saveNote.classList.remove("saved");
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => {
      DB.saveDraft(user.email, draft);
      saveNote.textContent = "All changes saved";
      saveNote.classList.add("saved");
      refreshCounts();
      renderCompleteness();
    }, 400);
  }

  // ---------------- side nav ----------------
  const navButtons = document.querySelectorAll("#editorNav button");
  navButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      navButtons.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      document.querySelectorAll(".panel-section").forEach((p) => p.classList.remove("active"));
      document.querySelector(`.panel-section[data-panel="${btn.dataset.target}"]`).classList.add("active");
    });
  });

  function refreshCounts() {
    ["education", "experience", "projects", "achievements", "links"].forEach((k) => {
      const el = document.getElementById(`cnt-${k}`);
      const n = k === "links" ? draft.personal.links.length : draft[k].length;
      el.textContent = n || "";
    });
    document.getElementById("cnt-skills").textContent = draft.skills.length || "";
  }

  // ---------------- personal info ----------------
  const p = draft.personal;
  document.getElementById("p-name").value = p.name || "";
  document.getElementById("p-title").value = p.title || "";
  document.getElementById("p-bio").value = p.bio || "";
  document.getElementById("p-email").value = p.email || "";
  document.getElementById("p-phone").value = p.phone || "";
  document.getElementById("p-location").value = p.location || "";
  [["p-name","name"],["p-title","title"],["p-bio","bio"],["p-email","email"],["p-phone","phone"],["p-location","location"]]
    .forEach(([id, field]) => {
      document.getElementById(id).addEventListener("input", (e) => {
        draft.personal[field] = e.target.value;
        scheduleSave();
      });
    });

  // ---------------- generic list sections ----------------
  const LIST_CONFIG = {
    education: {
      container: "list-education", label: "education", titleField: "school",
      fields: [
        { key: "school", label: "School", width: "full" },
        { key: "degree", label: "Degree", width: "half" },
        { key: "field", label: "Field of study", width: "half" },
        { key: "start", label: "Start", width: "half", placeholder: "2019" },
        { key: "end", label: "End", width: "half", placeholder: "2023" },
        { key: "description", label: "Notes", width: "full", area: true },
      ],
      blank: () => ({ id: DB.uid(), school: "", degree: "", field: "", start: "", end: "", description: "" }),
      source: () => draft.education,
    },
    experience: {
      container: "list-experience", label: "role", titleField: "company",
      fields: [
        { key: "company", label: "Company", width: "half" },
        { key: "role", label: "Role", width: "half" },
        { key: "start", label: "Start", width: "half", placeholder: "Jan 2023" },
        { key: "end", label: "End", width: "half", placeholder: "Present" },
        { key: "description", label: "What you did", width: "full", area: true },
      ],
      blank: () => ({ id: DB.uid(), company: "", role: "", start: "", end: "", description: "" }),
      source: () => draft.experience,
    },
    projects: {
      container: "list-projects", label: "project", titleField: "title",
      fields: [
        { key: "title", label: "Project title", width: "half" },
        { key: "tech", label: "Tech used", width: "half", placeholder: "React, Node, Postgres" },
        { key: "link", label: "Link", width: "full", placeholder: "https://…" },
        { key: "description", label: "Description", width: "full", area: true },
      ],
      blank: () => ({ id: DB.uid(), title: "", description: "", link: "", tech: "" }),
      source: () => draft.projects,
    },
    achievements: {
      container: "list-achievements", label: "achievement", titleField: "title",
      fields: [
        { key: "title", label: "Title", width: "half" },
        { key: "date", label: "Date", width: "half", placeholder: "2024" },
        { key: "description", label: "Description", width: "full", area: true },
      ],
      blank: () => ({ id: DB.uid(), title: "", description: "", date: "" }),
      source: () => draft.achievements,
    },
    links: {
      container: "list-links", label: "link", titleField: "label",
      fields: [
        { key: "label", label: "Label", width: "half", placeholder: "LinkedIn" },
        { key: "url", label: "URL", width: "half", placeholder: "https://…" },
      ],
      blank: () => ({ id: DB.uid(), label: "", url: "" }),
      source: () => draft.personal.links,
    },
  };

  function renderList(key) {
    const cfg = LIST_CONFIG[key];
    const container = document.getElementById(cfg.container);
    const items = cfg.source();
    container.innerHTML = "";
    if (!items.length) {
      const empty = document.createElement("p");
      empty.style.fontSize = "13.5px";
      empty.textContent = `No ${cfg.label} entries yet — add your first one.`;
      container.appendChild(empty);
      return;
    }
    items.forEach((item, idx) => {
      const card = document.createElement("div");
      card.className = "entry-card";

      const head = document.createElement("div");
      head.className = "entry-head";
      const tag = document.createElement("span");
      tag.className = "field-tag";
      tag.textContent = `${cfg.label.toUpperCase()}_${String(idx + 1).padStart(2, "0")}`;
      const actions = document.createElement("div");
      actions.className = "entry-actions";
      actions.appendChild(iconButton("↑", () => moveEntry(key, idx, -1)));
      actions.appendChild(iconButton("↓", () => moveEntry(key, idx, 1)));
      actions.appendChild(iconButton("✕", () => removeEntry(key, idx)));
      head.appendChild(tag);
      head.appendChild(actions);
      card.appendChild(head);

      const row = document.createElement("div");
      row.className = "entry-row";
      cfg.fields.forEach((f) => {
        const wrap = document.createElement("div");
        wrap.className = "field";
        if (f.width === "full") wrap.style.gridColumn = "1 / -1";
        const label = document.createElement("label");
        label.textContent = f.label;
        const input = document.createElement(f.area ? "textarea" : "input");
        if (!f.area) input.type = "text";
        input.placeholder = f.placeholder || "";
        input.value = item[f.key] || "";
        input.addEventListener("input", (e) => {
          items[idx][f.key] = e.target.value;
          scheduleSave();
        });
        wrap.appendChild(label);
        wrap.appendChild(input);
        row.appendChild(wrap);
      });
      card.appendChild(row);
      container.appendChild(card);
    });
  }

  function iconButton(symbol, onClick) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "icon-btn";
    btn.textContent = symbol;
    btn.addEventListener("click", onClick);
    return btn;
  }

  function addEntry(key) {
    const cfg = LIST_CONFIG[key];
    cfg.source().push(cfg.blank());
    scheduleSave();
    renderList(key);
  }
  function removeEntry(key, idx) {
    LIST_CONFIG[key].source().splice(idx, 1);
    scheduleSave();
    renderList(key);
  }
  function moveEntry(key, idx, dir) {
    const arr = LIST_CONFIG[key].source();
    const newIdx = idx + dir;
    if (newIdx < 0 || newIdx >= arr.length) return;
    [arr[idx], arr[newIdx]] = [arr[newIdx], arr[idx]];
    scheduleSave();
    renderList(key);
  }

  document.querySelectorAll("[data-add]").forEach((btn) => {
    btn.addEventListener("click", () => addEntry(btn.dataset.add));
  });
  Object.keys(LIST_CONFIG).forEach(renderList);

  // ---------------- skills ----------------
  function renderSkills() {
    const box = document.getElementById("skillTags");
    box.innerHTML = "";
    draft.skills.forEach((skill, idx) => {
      const tag = document.createElement("span");
      tag.className = "skill-tag";
      const txt = document.createElement("span");
      txt.textContent = skill;
      const remove = document.createElement("button");
      remove.type = "button";
      remove.textContent = "✕";
      remove.addEventListener("click", () => {
        draft.skills.splice(idx, 1);
        scheduleSave();
        renderSkills();
      });
      tag.appendChild(txt);
      tag.appendChild(remove);
      box.appendChild(tag);
    });
  }
  renderSkills();
  document.getElementById("skillInput").addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      const val = e.target.value.trim();
      if (val && !draft.skills.includes(val)) {
        draft.skills.push(val);
        scheduleSave();
        renderSkills();
      }
      e.target.value = "";
    }
  });

  // ---------------- template picker ----------------
  function renderTemplateSelection() {
    document.querySelectorAll(".template-card").forEach((card) => {
      card.classList.toggle("selected", card.dataset.template === draft.template);
    });
  }
  renderTemplateSelection();
  document.querySelectorAll(".template-card").forEach((card) => {
    card.addEventListener("click", () => {
      draft.template = card.dataset.template;
      scheduleSave();
      renderTemplateSelection();
    });
  });

  // ---------------- completeness (brownie point) ----------------
  function renderCompleteness() {
    const checks = [
      !!draft.personal.name, !!draft.personal.title, !!draft.personal.bio,
      draft.education.length > 0, draft.experience.length > 0,
      draft.projects.length > 0, draft.skills.length > 0, draft.achievements.length > 0,
    ];
    const score = Math.round((checks.filter(Boolean).length / checks.length) * 100);
    const box = document.getElementById("completeness");
    box.innerHTML = `
      <p class="field-tag">PORTFOLIO COMPLETENESS — ${score}%</p>
      <div class="progress-bar show" style="margin-top:8px;"><i style="width:${score}%;"></i></div>
      <p class="field-hint mt-8">${score < 100 ? "Fill in a bio, and at least one entry per section, for the strongest first impression." : "Every section has something in it — you're ready to publish."}</p>
    `;
  }
  renderCompleteness();

  // ---------------- preview / publish ----------------
  document.getElementById("previewBtn").addEventListener("click", (e) => {
    e.preventDefault();
    DB.saveDraft(user.email, draft);
    window.open(`portfolio.html?previewEmail=${encodeURIComponent(user.email)}`, "_blank");
  });

  document.getElementById("publishBtn").addEventListener("click", () => {
    if (!draft.personal.name) {
      alert("Add at least your name in Personal info before publishing.");
      return;
    }
    const slug = DB.publish(user.email, draft);
    const url = `${window.location.origin}${window.location.pathname.replace("editor.html", "")}portfolio.html?u=${slug}`;
    document.getElementById("publishedLink").value = url;
    document.getElementById("publishBox").classList.add("show");
  });

  document.getElementById("copyLinkBtn").addEventListener("click", () => {
    const input = document.getElementById("publishedLink");
    input.select();
    navigator.clipboard.writeText(input.value).then(() => {
      const btn = document.getElementById("copyLinkBtn");
      const original = btn.textContent;
      btn.textContent = "Copied!";
      setTimeout(() => (btn.textContent = original), 1500);
    });
  });

  if (draft.publishedSlug && DB.getPublished(draft.publishedSlug)) {
    const url = `${window.location.origin}${window.location.pathname.replace("editor.html", "")}portfolio.html?u=${draft.publishedSlug}`;
    document.getElementById("publishedLink").value = url;
    document.getElementById("publishBox").classList.add("show");
  }

  refreshCounts();
});
