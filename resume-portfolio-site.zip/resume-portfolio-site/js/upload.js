/* ============================================================
   upload.js
   Reads an uploaded PDF fully client-side (pdf.js), then runs a
   small heuristic parser to sort the text into resume sections.
   This is genuinely reading the file — not a fake progress bar —
   but heuristic text parsing is never perfect, so the result is
   handed to the editor for review, same as the brief asks for.
   ============================================================ */

// pdf.js itself (window.pdfjsLib) is loaded and configured by an
// inline module script in upload.html, since the 4.x cdnjs build
// is ES-module-only. We only ever touch it inside functions below,
// never at top-level, so load order between the two scripts doesn't matter.

const SECTION_PATTERNS = [
  { key: "education", re: /^(education|academics?|academic background)\b/i },
  { key: "experience", re: /^(work )?experience|employment history|professional experience/i },
  { key: "projects", re: /^projects?\b/i },
  { key: "skills", re: /^(technical )?skills|technologies|tech stack/i },
  { key: "achievements", re: /^achievements?|awards?|certifications?|honou?rs?/i },
  { key: "links", re: /^links?\b|contact\b/i },
];
const EMAIL_RE = /[\w.+-]+@[\w-]+\.[\w.-]+/;
const PHONE_RE = /(\+?\d[\d\s().-]{7,}\d)/;
const URL_RE = /((https?:\/\/)?(www\.)?[\w-]+\.(com|net|org|io|dev|me|in|co)[\w/\-?=&%.]*)/i;
const DATE_RANGE_RE = /(\b[A-Za-z]{3,9}\.?\s*\d{4}\b|\b\d{4}\b)\s*[-–—]+\s*(present|\b[A-Za-z]{3,9}\.?\s*\d{4}\b|\b\d{4}\b)/i;

function isLikelyHeader(line) {
  const t = line.trim();
  if (t.length > 42) return null;
  for (const p of SECTION_PATTERNS) if (p.re.test(t)) return p.key;
  return null;
}

async function extractPdfLines(file, log) {
  if (!window.pdfjsLib) throw new Error("PDF reader didn't load — check your connection");
  const buf = await file.arrayBuffer();
  const pdf = await window.pdfjsLib.getDocument({ data: buf }).promise;
  log(`Opened PDF — ${pdf.numPages} page(s) detected.`, "ok");
  const lines = [];
  for (let p = 1; p <= pdf.numPages; p++) {
    const page = await pdf.getPage(p);
    const content = await page.getTextContent();
    const byY = new Map();
    content.items.forEach((item) => {
      if (!item.str || !item.str.trim()) return;
      const y = Math.round(item.transform[5]);
      if (!byY.has(y)) byY.set(y, []);
      byY.get(y).push(item);
    });
    const ys = Array.from(byY.keys()).sort((a, b) => b - a);
    ys.forEach((y) => {
      const items = byY.get(y).sort((a, b) => a.transform[4] - b.transform[4]);
      const line = items.map((i) => i.str).join(" ").replace(/\s+/g, " ").trim();
      if (line) lines.push(line);
    });
  }
  log(`Pulled ${lines.length} line(s) of text.`, "ok");
  return lines;
}

function bucketLines(lines) {
  const buckets = { preamble: [], education: [], experience: [], projects: [], skills: [], achievements: [], links: [] };
  let current = "preamble";
  lines.forEach((line) => {
    const headerKey = isLikelyHeader(line);
    if (headerKey) { current = headerKey; return; }
    buckets[current].push(line);
  });
  return buckets;
}

function parsePersonal(preambleLines) {
  const contact = { email: "", phone: "", links: [] };
  const nameLines = [];
  preambleLines.slice(0, 12).forEach((line) => {
    const email = line.match(EMAIL_RE);
    const url = line.match(URL_RE);
    const phone = line.match(PHONE_RE);
    if (email) contact.email = email[0];
    else if (url) contact.links.push({ label: guessLinkLabel(url[0]), url: url[0].startsWith("http") ? url[0] : "https://" + url[0] });
    else if (phone && phone[0].replace(/\D/g, "").length >= 8) contact.phone = phone[0].trim();
    else nameLines.push(line);
  });
  return {
    name: nameLines[0] || "",
    title: nameLines[1] || "",
    bio: nameLines.slice(2).join(" ").slice(0, 400) || "",
    email: contact.email,
    phone: contact.phone,
    location: "",
    links: contact.links.length ? contact.links : [{ label: "LinkedIn", url: "" }, { label: "GitHub", url: "" }],
  };
}

function guessLinkLabel(url) {
  if (/linkedin/i.test(url)) return "LinkedIn";
  if (/github/i.test(url)) return "GitHub";
  return "Website";
}

function splitDates(str) {
  const m = str.match(DATE_RANGE_RE);
  if (!m) return { start: "", end: "", rest: str };
  return { start: m[1], end: m[2], rest: str.replace(m[0], "").replace(/[,|]\s*$/, "").trim() };
}

// turns a bucket of lines into entries, splitting a new entry
// whenever a line carries a date range (a common resume pattern)
function parseEntries(bucketLines) {
  const entries = [];
  let current = null;
  bucketLines.forEach((line) => {
    if (DATE_RANGE_RE.test(line) || !current) {
      const { start, end, rest } = splitDates(line);
      current = { headerRaw: rest || line, start, end, descLines: [] };
      entries.push(current);
    } else {
      current.descLines.push(line);
    }
  });
  return entries.filter((e) => e.headerRaw || e.descLines.length);
}

function toEducation(entries) {
  return entries.slice(0, 6).map((e) => {
    const parts = e.headerRaw.split(/\s*[|•·]\s*|\s{2,}/).filter(Boolean);
    return { id: DB.uid(), school: parts[0] || e.headerRaw, degree: parts[1] || "", field: parts[2] || "", start: e.start, end: e.end, description: e.descLines.join(" ").slice(0, 300) };
  });
}
function toExperience(entries) {
  return entries.slice(0, 8).map((e) => {
    const parts = e.headerRaw.split(/\s*[|•·]\s*|\s{2,}/).filter(Boolean);
    return { id: DB.uid(), company: parts[0] || e.headerRaw, role: parts[1] || "", start: e.start, end: e.end, description: e.descLines.join(" ").slice(0, 400) };
  });
}
function toProjects(entries) {
  return entries.slice(0, 8).map((e) => {
    const url = e.descLines.join(" ").match(URL_RE);
    return { id: DB.uid(), title: e.headerRaw, description: e.descLines.join(" ").slice(0, 400), link: url ? (url[0].startsWith("http") ? url[0] : "https://" + url[0]) : "", tech: "" };
  });
}
function toAchievements(entries) {
  return entries.slice(0, 8).map((e) => ({ id: DB.uid(), title: e.headerRaw, description: e.descLines.join(" ").slice(0, 300), date: e.start || e.end }));
}
function toSkills(lines) {
  const joined = lines.join(", ");
  return joined.split(/[,;•·|]/).map((s) => s.trim()).filter((s) => s && s.length < 34).slice(0, 24);
}

async function parseResume(file, log) {
  const lines = await extractPdfLines(file, log);
  if (!lines.length) throw new Error("No selectable text found — this may be a scanned image PDF.");
  const buckets = bucketLines(lines);
  log(`Sorting content into sections…`, "");
  const data = DB.emptyPortfolio();
  data.personal = parsePersonal(buckets.preamble);
  data.education = toEducation(parseEntries(buckets.education));
  data.experience = toExperience(parseEntries(buckets.experience));
  data.projects = toProjects(parseEntries(buckets.projects));
  data.achievements = toAchievements(parseEntries(buckets.achievements));
  data.skills = toSkills(buckets.skills);
  if (buckets.links.length) {
    data.personal.links = data.personal.links.concat(
      buckets.links.map((l) => {
        const m = l.match(URL_RE);
        return m ? { label: guessLinkLabel(m[0]), url: m[0].startsWith("http") ? m[0] : "https://" + m[0] } : null;
      }).filter(Boolean)
    );
  }
  log(`Found ${data.education.length} education, ${data.experience.length} experience, ${data.projects.length} project, ${data.achievements.length} achievement entr${data.achievements.length===1?"y":"ies"}, ${data.skills.length} skills.`, "ok");
  return data;
}

document.addEventListener("DOMContentLoaded", () => {
  const user = DB.requireAuth();
  if (!user) return;

  const dropzone = document.getElementById("dropzone");
  const fileInput = document.getElementById("fileInput");
  const chooseBtn = document.getElementById("chooseBtn");
  const progressBar = document.getElementById("progressBar");
  const progressFill = progressBar.querySelector("i");
  const logBox = document.getElementById("parseLog");
  const continueRow = document.getElementById("continueRow");
  const title = document.getElementById("uploaderTitle");
  const sub = document.getElementById("uploaderSub");

  function log(msg, cls) {
    logBox.classList.add("show");
    const div = document.createElement("div");
    if (cls) div.className = cls;
    div.textContent = msg;
    logBox.appendChild(div);
    logBox.scrollTop = logBox.scrollHeight;
  }
  function setProgress(pct) {
    progressBar.classList.add("show");
    progressFill.style.width = pct + "%";
  }

  chooseBtn.addEventListener("click", () => fileInput.click());
  dropzone.addEventListener("click", (e) => { if (e.target === dropzone) fileInput.click(); });
  ["dragenter", "dragover"].forEach((evt) =>
    dropzone.addEventListener(evt, (e) => { e.preventDefault(); dropzone.classList.add("drag"); })
  );
  ["dragleave", "drop"].forEach((evt) =>
    dropzone.addEventListener(evt, (e) => { e.preventDefault(); dropzone.classList.remove("drag"); })
  );
  dropzone.addEventListener("drop", (e) => {
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  });
  fileInput.addEventListener("change", () => {
    if (fileInput.files[0]) handleFile(fileInput.files[0]);
  });

  document.getElementById("skipBtn").addEventListener("click", () => {
    window.location.href = "editor.html";
  });

  async function handleFile(file) {
    title.textContent = file.name;
    sub.textContent = "Reading file…";
    logBox.innerHTML = "";
    setProgress(15);
    log(`Selected "${file.name}" (${(file.size / 1024).toFixed(0)} KB).`, "");

    const isPdf = file.type === "application/pdf" || /\.pdf$/i.test(file.name);
    if (!isPdf) {
      setProgress(100);
      log(`Automatic extraction currently supports PDF only. Loading a blank draft with your file name as a placeholder — fill in the rest in the editor.`, "warn");
      const data = mockExtractedData(file.name);
      DB.saveDraft(user.email, data);
      finish();
      return;
    }

    try {
      setProgress(40);
      const data = await parseResume(file, log);
      setProgress(85);
      if (!data.personal.name) data.personal.name = user.name;
      DB.saveDraft(user.email, data);
      setProgress(100);
      log(`Done — nothing was sent anywhere, this all happened in your browser.`, "ok");
      finish();
    } catch (err) {
      log(`Couldn't fully parse this file (${err.message}). Loading a blank draft instead — you can fill sections in manually.`, "warn");
      const data = mockExtractedData(file.name);
      data.personal.name = user.name;
      DB.saveDraft(user.email, data);
      setProgress(100);
      finish();
    }
  }

  function finish() {
    sub.textContent = "Extraction finished — review it in the editor.";
    continueRow.classList.remove("hidden");
  }
});
