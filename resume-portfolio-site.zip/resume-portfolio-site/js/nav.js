document.addEventListener("DOMContentLoaded", () => {
  const nav = document.querySelector(".site-nav");
  const toggle = document.querySelector(".nav-toggle");
  if (toggle && nav) {
    toggle.addEventListener("click", () => nav.classList.toggle("open"));
  }

  // highlight current page in nav
  const here = window.location.pathname.split("/").pop() || "index.html";
  document.querySelectorAll(".nav-links a").forEach((a) => {
    if (a.getAttribute("href") === here) a.classList.add("active");
  });

  // wire up any logout buttons
  document.querySelectorAll("[data-logout]").forEach((btn) => {
    btn.addEventListener("click", () => {
      DB.clearSession();
      window.location.href = "index.html";
    });
  });

  // reflect session state: swap "Log in / Sign up" for "Dashboard / Log out"
  const session = typeof DB !== "undefined" ? DB.getSession() : null;
  document.querySelectorAll("[data-auth-swap]").forEach((el) => {
    el.classList.toggle("hidden", !!session);
  });
  document.querySelectorAll("[data-auth-only]").forEach((el) => {
    el.classList.toggle("hidden", !session);
  });
});
