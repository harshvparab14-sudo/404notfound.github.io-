/* ============================================================
   storage.js — the "database" for this static, front-end-only
   build. Everything lives in localStorage, scoped to whichever
   browser the user is in.

   IMPORTANT LIMITATION (see README): because there is no server,
   a "published" portfolio link only resolves on the SAME browser
   that published it. To make links resolve for anyone, anywhere,
   swap this file's storage calls for a real backend (Firebase,
   Supabase, or a small Node/Express API) — every other page
   only talks to the functions in this file, so that's the one
   place you'd need to change.
   ============================================================ */

const DB = {
  KEYS: {
    USERS: "rp_users",
    SESSION: "rp_session",
    DRAFT_PREFIX: "rp_draft_",
    PUBLISHED_PREFIX: "rp_published_",
  },

  _read(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (e) {
      return fallback;
    }
  },
  _write(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  },

  // ---------- users / session ----------
  // NOTE: this is a MOCK auth system for demo purposes only —
  // passwords are stored in plain text in the browser. Never do
  // this in a real product; swap in real auth (Firebase Auth,
  // Auth0, your own backend) before this goes anywhere near
  // real users.
  getUsers() { return this._read(this.KEYS.USERS, {}); },
  saveUser(user) {
    const users = this.getUsers();
    users[user.email] = user;
    this._write(this.KEYS.USERS, users);
  },
  findUser(email) {
    return this.getUsers()[email.toLowerCase().trim()] || null;
  },
  setSession(email) { this._write(this.KEYS.SESSION, { email }); },
  getSession() { return this._read(this.KEYS.SESSION, null); },
  clearSession() { localStorage.removeItem(this.KEYS.SESSION); },
  currentUser() {
    const s = this.getSession();
    if (!s) return null;
    return this.findUser(s.email);
  },
  requireAuth() {
    if (!this.getSession()) {
      window.location.href = "login.html";
      return null;
    }
    return this.currentUser();
  },

  // ---------- portfolio draft (per user, editable) ----------
  emptyPortfolio() {
    return {
      personal: { name: "", title: "", bio: "", email: "", phone: "", location: "", links: [] },
      education: [],
      experience: [],
      projects: [],
      skills: [],
      achievements: [],
      template: "modern",
      publishedSlug: null,
      updatedAt: null,
    };
  },
  getDraft(email) {
    return this._read(this.KEYS.DRAFT_PREFIX + email, this.emptyPortfolio());
  },
  saveDraft(email, data) {
    data.updatedAt = new Date().toISOString();
    this._write(this.KEYS.DRAFT_PREFIX + email, data);
  },

  // ---------- published (public, keyed by slug) ----------
  slugify(name) {
    const base = (name || "portfolio")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "") || "portfolio";
    const rand = Math.random().toString(36).slice(2, 6);
    return `${base}-${rand}`;
  },
  publish(email, data) {
    const slug = data.publishedSlug || this.slugify(data.personal.name);
    data.publishedSlug = slug;
    this._write(this.KEYS.PUBLISHED_PREFIX + slug, data);
    this.saveDraft(email, data);
    return slug;
  },
  getPublished(slug) {
    return this._read(this.KEYS.PUBLISHED_PREFIX + slug, null);
  },

  // ---------- small id helper for list entries ----------
  uid() { return Math.random().toString(36).slice(2, 10); },
};

// mock data dropped into a draft right after "extraction" on the
// upload page — stands in for a real PDF/NLP parser's output.
function mockExtractedData(fileName) {
  const displayName = (fileName || "Your Name").replace(/\.[^.]+$/, "").replace(/[_-]+/g, " ");
  return {
    personal: {
      name: titleCase(displayName) || "Your Name",
      title: "Software Engineer",
      bio: "Detected from your resume header — rewrite this into a short introduction of who you are and what you build.",
      email: "you@example.com",
      phone: "",
      location: "",
      links: [{ label: "LinkedIn", url: "" }, { label: "GitHub", url: "" }],
    },
    education: [
      { id: DB.uid(), school: "Detected institution", degree: "Detected degree", field: "", start: "", end: "", description: "" },
    ],
    experience: [
      { id: DB.uid(), company: "Detected company", role: "Detected role", start: "", end: "", description: "Add a line or two on what you owned and shipped here." },
    ],
    projects: [
      { id: DB.uid(), title: "Detected project", description: "Short summary of the project and your role in it.", link: "", tech: "" },
    ],
    skills: ["Communication", "Problem solving"],
    achievements: [
      { id: DB.uid(), title: "Detected achievement", description: "", date: "" },
    ],
    template: "modern",
    publishedSlug: null,
    updatedAt: null,
  };
}
function titleCase(s) {
  return s.replace(/\w\S*/g, (t) => t[0].toUpperCase() + t.slice(1).toLowerCase());
}
