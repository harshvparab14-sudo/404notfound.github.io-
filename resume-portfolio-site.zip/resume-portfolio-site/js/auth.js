document.addEventListener("DOMContentLoaded", () => {
  const errorBox = document.getElementById("formError");
  const showError = (msg) => {
    if (!errorBox) return;
    errorBox.textContent = msg;
    errorBox.classList.add("show");
  };

  const signupForm = document.getElementById("signupForm");
  if (signupForm) {
    signupForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const name = document.getElementById("name").value.trim();
      const email = document.getElementById("email").value.trim().toLowerCase();
      const password = document.getElementById("password").value;

      if (!name || !email || password.length < 6) {
        showError("Please fill every field — password needs at least 6 characters.");
        return;
      }
      if (DB.findUser(email)) {
        showError("An account with that email already exists — try logging in instead.");
        return;
      }
      DB.saveUser({ name, email, password });
      DB.setSession(email);
      window.location.href = "dashboard.html";
    });
  }

  const loginForm = document.getElementById("loginForm");
  if (loginForm) {
    loginForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const email = document.getElementById("email").value.trim().toLowerCase();
      const password = document.getElementById("password").value;
      const user = DB.findUser(email);

      if (!user || user.password !== password) {
        showError("That email and password don't match any account here.");
        return;
      }
      DB.setSession(email);
      window.location.href = "dashboard.html";
    });
  }
});
