# Portfolio, Unfolded

A front-end-only implementation of **Problem Statement 02 — "Escape the PDF Prison"**
(GNKC Inter-Collegiate Hackathon 2026): turn a resume into a shareable, editable
portfolio site. Pure HTML/CSS/JavaScript — no build step, no framework, no server —
so it can be pushed straight to GitHub and hosted on **GitHub Pages**.

## What's in here

```
index.html        Landing page
signup.html       Create account
login.html        Log in
dashboard.html    Status overview + links to each step
upload.html       Drop in a resume PDF, watch it get parsed
editor.html       Review/edit every section, pick a layout, publish
portfolio.html    The public, published portfolio (reads ?u=<slug>)
css/style.css     Everything's styling
js/storage.js     The "database" — all data lives in localStorage
js/auth.js        Sign up / log in logic
js/upload.js      Client-side PDF text extraction + section parser
js/editor.js      Add/remove/reorder sections, skills, templates, publish
js/portfolio.js   Renders a published (or preview) portfolio
js/nav.js         Mobile nav toggle + logged-in/out nav state
```

## Running it locally

No build step needed. From this folder:

```bash
python3 -m http.server 8080
```

Then open `http://localhost:8080`. (Opening `index.html` directly via
`file://` also mostly works, but some browsers restrict `fetch`/module
loading over `file://` — a local server is safer.)

## Putting it on GitHub Pages

1. Create a new repository on GitHub and push this folder to it:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/<you>/<repo>.git
   git push -u origin main
   ```
2. In the repo, go to **Settings → Pages**.
3. Under **Build and deployment**, set **Source** to "Deploy from a branch",
   branch `main`, folder `/ (root)`.
4. Save. GitHub gives you a URL like `https://<you>.github.io/<repo>/` —
   that's your live site.

You can do all of this from **GitHub Desktop** too: open this folder as a
local repository, commit, publish the repository, then turn on Pages from
the repo's Settings page in your browser.

## How the "extraction" actually works

Feature #2 in the brief ("resume upload and structured information
extraction") is implemented for real, not mocked: `upload.html` loads
**pdf.js** from a CDN and reads the PDF's text directly in the browser
(nothing is uploaded anywhere). `js/upload.js` then runs a small heuristic
parser — it looks for lines that look like section headers ("Education",
"Experience", "Projects", "Skills", "Achievements"), groups the lines under
each one, and tries to split entries apart using date ranges (e.g. "2019 –
2023"). Heuristic parsing of arbitrary resume layouts is never perfect,
which is exactly why the next step is the editor: everything extracted is
fully editable, addable, and removable before anything is published.
Non-PDF files currently fall back to a blank/manual entry, since accurate
DOCX parsing needs another library.

## Important limitation: this is a front-end-only demo

There's no backend and no real database — `js/storage.js` uses the
browser's `localStorage` to stand in for one. That means:

- **Accounts are mock accounts.** Signing up stores name/email/password in
  plain text in your own browser's localStorage. This is fine for a demo
  or a hackathon judge to click through, but it is **not real
  authentication** — don't point real users at it as-is.
- **Published links only resolve in the same browser that published
  them.** A "unique shareable public link" (feature #8) needs a real
  database so any device can look up a slug and get the same data back.
  Right now, `portfolio.html?u=<slug>` reads from that browser's
  localStorage, so if you email the link to someone else, they'll see a
  "nothing published here yet" message on their own device.

### The upgrade path

Every page only ever talks to the functions in `js/storage.js`
(`saveUser`, `findUser`, `getDraft`, `saveDraft`, `publish`, `getPublished`,
etc.) — nothing else touches `localStorage` directly. To make this a real
multi-device product, that's the one file to change: swap those functions
for calls to a real backend, for example:

- **Firebase** (Auth + Firestore) — fastest to wire up, no server to run,
  works fine from a static GitHub Pages site.
- **Supabase** — same idea, Postgres-backed.
- **Your own small API** (Node/Express, etc.) — most control, but you'd
  need to host it somewhere other than GitHub Pages (which only serves
  static files).

## Brownie-point features already included

- **Portfolio completeness meter** — the "Layout & publish" tab in the
  editor scores how filled-out the draft is.
- **Template switching without data loss** — the three layouts (Modern,
  Mono, Timeline) all read from the same underlying data, so switching is
  instant and nothing is re-entered.

Not yet built (left for a next pass, once a backend exists): AI-generated
bios/summaries, content-quality suggestions, visit analytics, and
export/download of the finished portfolio.
